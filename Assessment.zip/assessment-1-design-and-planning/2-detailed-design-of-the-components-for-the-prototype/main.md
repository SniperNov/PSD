# Detailed design of the components for the prototype

## Table of Contents
1. [Introduction](./1-intro.md)
2. [Requirements engineering](./2-requirements-engineering.md)
3. [Design](./3-design-language-and-technology-choices.md)
4. [Timeline](./4-timeline.md)
