# Summative Group Assessment 1: Design and Planning

## A high-level design of the end-to-end solution

The report related to a high-level design can be found here: 
[A high-level design report](./1-high-level-design-of-the-end-to-end-solution/main.md)

## A detailed design of the component(s) you and your team prioritised for your prototype

The report related to a detailed design of the components for the prototype can be found here:
[A detailed design of the components for the prototype report](./2-detailed-design-of-the-components-for-the-prototype/main.md)
