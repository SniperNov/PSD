# High level design of the end-to-end solution Report

## Table of Contents
1. [Original requirements](./1-intro.md)
2. [Requirements decomposition](./2-initial-requirements-decomposition.md)
3. [Approached design](./3-approached-ui-design.md)
3. [High level architecture](./4-high-level-architecture.md)
