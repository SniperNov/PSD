## Continuous integration and deployment

We can use gitlab pipelines as continuous integration tool to cover all the thing mentioned in the
defects section. 

This can be an additional source of information about running environment, a better source of documentation, 
quality control gate, and a source of additional program metrics.  