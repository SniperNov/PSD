## Redundant readme steps

We can place directories Docs, Ents, JSON, data under git and add related .gitignore files to ignore everything inside
those directories.

## Unwanted files can be added into git by mistake

Knowing all types of files that are going to be created during the program execution we can add those types to 
.gitignore as well. 



