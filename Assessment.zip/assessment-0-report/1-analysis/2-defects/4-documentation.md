## Documentation

In terms of documentation we have the following problems:

1. Missing deployment documentation.
2. Missing python3, pip, system dependencies information.
3. Missing Input/Output documentation. 
4. Missing Use cases or Sort of problem we are solving.

All of that creates additional problems for developers that are going to work with the code. 

