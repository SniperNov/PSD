## Continuous integration and deployment

In addition to missing tests we can highlight, that there is no information available about Continuous integration and 
deployment. Usually it is used to control code style, run code linters, check code coverage, run tests, validate
dependencies, update minor versions of the dependencies etc. 

This can be an additional source of information about running environment, a better source of documentation, 
quality control gate, and a source of additional program metrics.  