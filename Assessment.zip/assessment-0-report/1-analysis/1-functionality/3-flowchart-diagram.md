## Diagram

![Flow chart showing how prototype.py processes](./image1.jpg)

Original draw.io file can we found here [Prototype_FlowChart](./Prototype_FlowChart)